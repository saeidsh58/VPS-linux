# colab-free-vps
A Free Linux VPS from Colab


open this link and follow the procedures

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/gokulapap/colab-free-vps)
